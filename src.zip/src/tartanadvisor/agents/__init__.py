import os
from crewai.agent import Agent
from crewai import LLM
from src.tools.vector_search import VectorSearchTool
from tartanadvisor.utils.embedding import load_and_embed
from tartanadvisor.utils.faiss_store import FaissStore
import yaml

def load_faiss_stores(config_path="config/faiss_stores.yaml", only: str = None):
    """
    Load FAISS stores from YAML.
    If `only` is given, load and return just that one store.
    Otherwise, return the full dict of all stores.
    """
    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)["stores"]

    if only:
        params = cfg.get(only)
        if not params:
            raise KeyError(f"No FAISS store named '{only}' in config")
        return {only: FaissStore(**params)}

    # full load
    return {
        name: FaissStore(**params)
        for name, params in cfg.items()
    }

def make_advising_agent():
    llm = LLM(model=os.getenv("MODEL"))
    faiss_stores = load_faiss_stores(only="courses")
    vector_tool = VectorSearchTool(faiss_stores, embed_fn=load_and_embed)
    # add any other tools here
    return Agent(
        llm=llm,
        tools=[vector_tool],
        # memory, etc.
    )